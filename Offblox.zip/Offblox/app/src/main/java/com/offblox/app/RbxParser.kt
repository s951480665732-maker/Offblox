package com.offblox.app

import com.github.luben.zstd.Zstd

class Part(
    val s: FloatArray,   // размер x,y,z
    val m: FloatArray,   // 9 чисел поворота (по строкам) + 3 числа позиции
    val r: Float, val g: Float, val b: Float,
    val t: Float,        // прозрачность
    val cc: Boolean,     // CanCollide
    val spawn: Boolean
)

class Place(val parts: List<Part>, val total: Int)

private class Inst(val cls: String) {
    var par = -1
    var size: FloatArray? = null
    var cf: FloatArray? = null
    var col: FloatArray? = null
    var tr = 0f
    var cc = true
}

object RbxParser {
    private val AX = arrayOf(
        floatArrayOf(1f, 0f, 0f), floatArrayOf(0f, 1f, 0f), floatArrayOf(0f, 0f, 1f),
        floatArrayOf(-1f, 0f, 0f), floatArrayOf(0f, -1f, 0f), floatArrayOf(0f, 0f, -1f)
    )

    private fun u8(d: ByteArray, o: Int) = d[o].toInt() and 255
    private fun i32(d: ByteArray, o: Int) =
        u8(d, o) or (u8(d, o + 1) shl 8) or (u8(d, o + 2) shl 16) or (u8(d, o + 3) shl 24)

    // значения Roblox хранятся «вперемешку по байтам»
    private fun arr(d: ByteArray, o: Int, n: Int) = IntArray(n) { i ->
        (u8(d, o + i) shl 24) or (u8(d, o + n + i) shl 16) or (u8(d, o + 2 * n + i) shl 8) or u8(d, o + 3 * n + i)
    }

    private fun zz(v: Int) = (v ushr 1) xor -(v and 1)

    private fun delta(a: IntArray): IntArray {
        var s = 0
        return IntArray(a.size) { s += zz(a[it]); s }
    }

    private fun flt(d: ByteArray, o: Int, n: Int): FloatArray {
        val a = arr(d, o, n)
        return FloatArray(n) { java.lang.Float.intBitsToFloat((a[it] ushr 1) or (a[it] shl 31)) }
    }

    private fun str(d: ByteArray, o: Int): Pair<String, Int> {
        val l = i32(d, o)
        return Pair(String(d, o + 4, l, Charsets.UTF_8), o + 4 + l)
    }

    private fun lz4(s: ByteArray, n: Int): ByteArray {
        val o = ByteArray(n)
        var i = 0
        var j = 0
        while (i < s.size) {
            val t = u8(s, i++)
            var l = t shr 4
            if (l == 15) { var b: Int; do { b = u8(s, i++); l += b } while (b == 255) }
            while (l-- > 0) o[j++] = s[i++]
            if (i >= s.size) break
            val f = u8(s, i) or (u8(s, i + 1) shl 8)
            i += 2
            var m = t and 15
            if (m == 15) { var b: Int; do { b = u8(s, i++); m += b } while (b == 255) }
            m += 4
            while (m-- > 0) { o[j] = o[j - f]; j++ }
        }
        return o
    }

    fun parse(buf: ByteArray): Place {
        if (buf.size < 40 || String(buf, 0, 8, Charsets.ISO_8859_1) != "<roblox!")
            throw IllegalArgumentException("нужен бинарный .rbxl (не .rbxlx и не .rbxm)")
        val classes = HashMap<Int, Pair<String, IntArray>>()
        val inst = HashMap<Int, Inst>()
        var p = 32
        while (p + 16 <= buf.size) {
            val name = String(buf, p, 4, Charsets.ISO_8859_1)
            val cl = i32(buf, p + 4)
            val ul = i32(buf, p + 8)
            p += 16
            val d: ByteArray
            if (cl > 0) {
                val c = buf.copyOfRange(p, p + cl)
                p += cl
                d = if (u8(c, 0) == 0x28 && u8(c, 1) == 0xB5) Zstd.decompress(c, ul) else lz4(c, ul)
            } else {
                d = buf.copyOfRange(p, p + ul)
                p += ul
            }
            when (name) {
                "INST" -> {
                    val id = i32(d, 0)
                    val (cn, o0) = str(d, 4)
                    var o = o0 + 1
                    val k = i32(d, o); o += 4
                    val ids = delta(arr(d, o, k))
                    classes[id] = Pair(cn, ids)
                    for (i in ids) inst[i] = Inst(cn)
                }
                "PROP" -> {
                    val cls = classes[i32(d, 0)] ?: continue
                    val (pn, o0) = str(d, 4)
                    var o = o0
                    val ty = u8(d, o++)
                    val ids = cls.second
                    val k = ids.size
                    when (pn) {
                        "size" -> if (ty == 14) {
                            val x = flt(d, o, k); val y = flt(d, o + 4 * k, k); val z = flt(d, o + 8 * k, k)
                            for (i in 0 until k) inst[ids[i]]!!.size = floatArrayOf(x[i], y[i], z[i])
                        }
                        "CFrame" -> if (ty == 16) {
                            val rots = ArrayList<FloatArray>(k)
                            for (i in 0 until k) {
                                val id = u8(d, o++)
                                if (id != 0) {
                                    val a = AX[((id - 1) / 6).coerceIn(0, 5)]
                                    val u = AX[((id - 1) % 6).coerceIn(0, 5)]
                                    rots.add(floatArrayOf(
                                        a[0], u[0], a[1] * u[2] - a[2] * u[1],
                                        a[1], u[1], a[2] * u[0] - a[0] * u[2],
                                        a[2], u[2], a[0] * u[1] - a[1] * u[0]))
                                } else {
                                    val base = o
                                    rots.add(FloatArray(9) { j -> java.lang.Float.intBitsToFloat(i32(d, base + 4 * j)) })
                                    o += 36
                                }
                            }
                            val x = flt(d, o, k); val y = flt(d, o + 4 * k, k); val z = flt(d, o + 8 * k, k)
                            for (i in 0 until k) {
                                val r = rots[i]
                                inst[ids[i]]!!.cf = floatArrayOf(r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8], x[i], y[i], z[i])
                            }
                        }
                        "Color3uint8" -> if (ty == 26) {
                            for (i in 0 until k) inst[ids[i]]!!.col = floatArrayOf(
                                u8(d, o + i) / 255f, u8(d, o + k + i) / 255f, u8(d, o + 2 * k + i) / 255f)
                        }
                        "Transparency" -> if (ty == 4) {
                            val t = flt(d, o, k)
                            for (i in 0 until k) inst[ids[i]]!!.tr = t[i]
                        }
                        "CanCollide" -> if (ty == 2) {
                            for (i in 0 until k) inst[ids[i]]!!.cc = u8(d, o + i) != 0
                        }
                    }
                }
                "PRNT" -> {
                    val k = i32(d, 1)
                    val c = delta(arr(d, 5, k))
                    val q = delta(arr(d, 5 + 4 * k, k))
                    for (i in 0 until k) inst[c[i]]?.par = q[i]
                }
            }
            if (name.startsWith("END")) break
        }
        val out = ArrayList<Part>()
        var total = 0
        for ((_, x) in inst) {
            val sz = x.size ?: continue
            val cf = x.cf ?: continue
            var cur: Inst? = x
            var ok = false
            var guard = 0
            while (cur != null && guard++ < 200) {
                if (cur.cls == "Workspace") { ok = true; break }
                cur = inst[cur.par]
            }
            if (!ok) continue
            total++
            val c = x.col ?: floatArrayOf(163 / 255f, 162 / 255f, 165 / 255f)
            if (x.tr < 0.9f || x.cc) out.add(Part(sz, cf, c[0], c[1], c[2], x.tr, x.cc, x.cls == "SpawnLocation"))
        }
        return Place(out, total)
    }
}

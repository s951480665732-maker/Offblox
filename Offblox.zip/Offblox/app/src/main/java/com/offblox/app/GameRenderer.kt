package com.offblox.app

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

private const val VS = """
uniform mat4 uVP;
uniform mat4 uModel;
attribute vec3 aPos;
attribute vec3 aNor;
attribute vec3 aCol;
varying vec3 vCol;
varying float vDist;
void main() {
    gl_Position = uVP * (uModel * vec4(aPos, 1.0));
    vec3 n = normalize((uModel * vec4(aNor, 0.0)).xyz);
    float l = 0.5 + 0.2 * n.y + 0.4 * max(dot(n, normalize(vec3(0.4, 0.9, 0.3))), 0.0);
    vCol = aCol * l;
    vDist = gl_Position.w;
}
"""

private const val FS = """
precision mediump float;
varying vec3 vCol;
varying float vDist;
void main() {
    float f = clamp((vDist - 300.0) / 1200.0, 0.0, 1.0);
    gl_FragColor = vec4(mix(vCol, vec3(0.56, 0.82, 1.0), f), 1.0);
}
"""

class GameRenderer(private val world: World) : GLSurfaceView.Renderer {
    // управление (пишется из интерфейса, читается в потоке GL)
    @Volatile var joyX = 0f
    @Volatile var joyY = 0f
    @Volatile var jump = false
    @Volatile var yaw = 0f
    @Volatile var pitch = 0.35f

    private class Gpu(val vbo: Int, val ibo: Int, val n: Int)

    private var prog = 0
    private var aPos = 0
    private var aNor = 0
    private var aCol = 0
    private var uVP = 0
    private var uModel = 0
    private val gpu = ArrayList<Gpu>()
    private var avatarGpu: Gpu? = null

    private val proj = FloatArray(16)
    private val view = FloatArray(16)
    private val vp = FloatArray(16)
    private val model = FloatArray(16)

    private var px = world.spawn[0]
    private var py = world.spawn[1] + 3f
    private var pz = world.spawn[2]
    private var vy = 0f
    private var grounded = false
    private var facing = 0f
    private var last = 0L

    private fun shader(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        return s
    }

    private fun upload(b: Batch): Gpu {
        val fb = ByteBuffer.allocateDirect(b.v.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        fb.put(b.v).position(0)
        val ib = ByteBuffer.allocateDirect(b.idx.size * 2).order(ByteOrder.nativeOrder()).asShortBuffer()
        ib.put(b.idx).position(0)
        val ids = IntArray(2)
        GLES20.glGenBuffers(2, ids, 0)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, ids[0])
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, b.v.size * 4, fb, GLES20.GL_STATIC_DRAW)
        GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, ids[1])
        GLES20.glBufferData(GLES20.GL_ELEMENT_ARRAY_BUFFER, b.idx.size * 2, ib, GLES20.GL_STATIC_DRAW)
        return Gpu(ids[0], ids[1], b.idx.size)
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.56f, 0.82f, 1f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, shader(GLES20.GL_VERTEX_SHADER, VS))
        GLES20.glAttachShader(prog, shader(GLES20.GL_FRAGMENT_SHADER, FS))
        GLES20.glLinkProgram(prog)
        aPos = GLES20.glGetAttribLocation(prog, "aPos")
        aNor = GLES20.glGetAttribLocation(prog, "aNor")
        aCol = GLES20.glGetAttribLocation(prog, "aCol")
        uVP = GLES20.glGetUniformLocation(prog, "uVP")
        uModel = GLES20.glGetUniformLocation(prog, "uModel")
        gpu.clear()
        for (b in world.batches) gpu.add(upload(b))
        avatarGpu = upload(world.avatar)
        last = 0L
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        GLES20.glViewport(0, 0, w, h)
        Matrix.perspectiveM(proj, 0, 65f, w.toFloat() / max(h, 1), 1f, 4000f)
    }

    private fun step(dt: Float) {
        var ix = joyX
        var iy = joyY
        val l = hypot(ix, iy)
        if (l > 1f) { ix /= l; iy /= l }
        val sy = sin(yaw)
        val cy = cos(yaw)
        val mx = ix * cy - iy * sy
        val mz = -ix * sy - iy * cy
        if (l > .05f) {
            val nx = px + mx * 16f * dt
            val nz = pz + mz * 16f * dt
            if (!world.blocked(nx, pz, py)) px = nx
            if (!world.blocked(px, nz, py)) pz = nz
            facing = atan2(-mx, -mz)
        }
        if (jump && grounded) { vy = 50f; grounded = false }
        vy = max(vy - 196f * dt, -150f)
        val ny = py + vy * dt
        val g = world.top(px, pz, py)
        if (vy <= 0f && ny <= g) { py = g; vy = 0f; grounded = true } else { py = ny; grounded = false }
        if (py < world.minY - 150f) {
            px = world.spawn[0]; py = world.spawn[1] + 3f; pz = world.spawn[2]; vy = 0f
        }
    }

    private fun draw(g: Gpu) {
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, g.vbo)
        GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, g.ibo)
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 36, 0)
        GLES20.glEnableVertexAttribArray(aNor)
        GLES20.glVertexAttribPointer(aNor, 3, GLES20.GL_FLOAT, false, 36, 12)
        GLES20.glEnableVertexAttribArray(aCol)
        GLES20.glVertexAttribPointer(aCol, 3, GLES20.GL_FLOAT, false, 36, 24)
        GLES20.glDrawElements(GLES20.GL_TRIANGLES, g.n, GLES20.GL_UNSIGNED_SHORT, 0)
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        val dt = if (last == 0L) 0.016f else min((now - last) / 1e9f, 0.033f)
        last = now
        step(dt)

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        val cp = cos(pitch)
        val d = 14f
        Matrix.setLookAtM(view, 0,
            px + sin(yaw) * cp * d, py + 3f + sin(pitch) * d, pz + cos(yaw) * cp * d,
            px, py + 3f, pz, 0f, 1f, 0f)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)
        GLES20.glUseProgram(prog)
        GLES20.glUniformMatrix4fv(uVP, 1, false, vp, 0)

        Matrix.setIdentityM(model, 0)
        GLES20.glUniformMatrix4fv(uModel, 1, false, model, 0)
        for (g in gpu) draw(g)

        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, px, py, pz)
        Matrix.rotateM(model, 0, Math.toDegrees(facing.toDouble()).toFloat(), 0f, 1f, 0f)
        GLES20.glUniformMatrix4fv(uModel, 1, false, model, 0)
        avatarGpu?.let { draw(it) }
    }
}

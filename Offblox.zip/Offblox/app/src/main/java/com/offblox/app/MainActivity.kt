package com.offblox.app

import android.content.Context
import android.net.Uri
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.hypot

private val Violet = Color(0xFF7B3FE4)
private val Deep = Color(0xFF4B1DB0)
private val Night = Color(0xFF1C0A45)
private val Panel = Color(0xFF2E1370)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val lib = Library(applicationContext)
        setContent { OffbloxApp(lib) }
    }
}

private fun nameOf(ctx: Context, uri: Uri): String {
    var n = "Игра"
    ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
        if (it.moveToFirst()) n = it.getString(0) ?: n
    }
    return n.replace(Regex("\\.rbxlx?$", RegexOption.IGNORE_CASE), "")
}

@Composable
fun OffbloxApp(lib: Library) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var games by remember { mutableStateOf(lib.list()) }
    var current by remember { mutableStateOf<Pair<World, Int>?>(null) }
    var loading by remember { mutableStateOf<String?>(null) }
    fun toast(t: String) = Toast.makeText(ctx, t, Toast.LENGTH_LONG).show()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch {
            loading = "Читаю файл…"
            try {
                val e = withContext(Dispatchers.IO) {
                    val bytes = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                    val place = RbxParser.parse(bytes)
                    if (place.total == 0) throw IllegalArgumentException("в Workspace нет объектов")
                    lib.add(nameOf(ctx, uri), bytes, place.total)
                }
                games = lib.list()
                toast("Добавлено: ${e.name}")
            } catch (t: Throwable) {
                toast("Не получилось: ${t.message}")
            }
            loading = null
        }
    }

    fun play(g: GameEntry) {
        scope.launch {
            loading = "Загружаю «${g.name}»…"
            try {
                val w = withContext(Dispatchers.Default) { World(RbxParser.parse(lib.read(g.id))) }
                current = Pair(w, g.count)
            } catch (t: Throwable) {
                toast("Ошибка: ${t.message}")
            }
            loading = null
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Violet, background = Night, surface = Panel)) {
        Surface(Modifier.fillMaxSize(), color = Night) {
            val c = current
            if (c != null) {
                BackHandler { current = null }
                GameScreen(c.first, c.second) { current = null }
            } else {
                LibraryScreen(
                    games,
                    onImport = { picker.launch(arrayOf("*/*")) },
                    onPlay = { play(it) },
                    onDelete = { lib.remove(it.id); games = lib.list() }
                )
            }
            val msg = loading
            if (msg != null) {
                Box(
                    Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Deep, Violet))),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = Color.White)
                        Spacer(Modifier.height(16.dp))
                        Text(msg, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp, textAlign = TextAlign.Center)
                    }
                }
            }
        }
    }
}

@Composable
fun Logo() {
    Box(
        Modifier.size(42.dp).clip(RoundedCornerShape(10.dp))
            .background(Brush.linearGradient(listOf(Color(0xFFB57BFF), Color(0xFF5A1FC8)))),
        contentAlignment = Alignment.Center
    ) {
        Text("RB", color = Color.White, fontWeight = FontWeight.Black, fontSize = 19.sp)
    }
}

@Composable
fun LibraryScreen(games: List<GameEntry>, onImport: () -> Unit, onPlay: (GameEntry) -> Unit, onDelete: (GameEntry) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Deep, Violet)))
                .statusBarsPadding().padding(16.dp, 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Logo()
            Spacer(Modifier.width(10.dp))
            Text("Офблокс", color = Color.White, fontWeight = FontWeight.Black, fontSize = 22.sp)
            Spacer(Modifier.weight(1f))
            Button(
                onClick = onImport,
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Deep)
            ) { Text("⬆ Импорт", fontWeight = FontWeight.Bold) }
        }
        Text("Мои игры", Modifier.padding(16.dp, 16.dp, 16.dp, 0.dp), color = Color(0xFFF3ECFF), fontWeight = FontWeight.Black, fontSize = 26.sp)
        Text(
            "Нажми «Импорт» и выбери файл плейса .rbxl из Roblox Studio.",
            Modifier.padding(16.dp, 2.dp, 16.dp, 0.dp), color = Color(0xFFB9A3EE)
        )
        LazyVerticalGrid(
            GridCells.Adaptive(150.dp),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Column(
                    Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(16.dp))
                        .border(2.dp, Color(0xFFA66BFF), RoundedCornerShape(16.dp)).clickable { onImport() },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("＋", color = Color(0xFFA66BFF), fontSize = 44.sp)
                    Text("Импорт игры", color = Color(0xFFA66BFF), fontWeight = FontWeight.Bold)
                }
            }
            items(games, key = { it.id }) { g -> GameCard(g, onPlay, onDelete) }
        }
    }
}

@Composable
fun GameCard(g: GameEntry, onPlay: (GameEntry) -> Unit, onDelete: (GameEntry) -> Unit) {
    var h = 0
    for (ch in g.name) h = (h * 31 + ch.code) % 80
    val hue = 250f + h
    Column(Modifier.clip(RoundedCornerShape(16.dp)).background(Panel)) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(1.4f).background(
                Brush.linearGradient(listOf(Color.hsv(hue % 360f, .75f, .85f), Color.hsv((hue + 35f) % 360f, .7f, .35f)))
            )
        ) {
            Text(
                "${g.count} объектов",
                Modifier.align(Alignment.BottomStart).padding(8.dp)
                    .background(Color(0x88000000), RoundedCornerShape(8.dp)).padding(8.dp, 2.dp),
                color = Color.White, fontSize = 12.sp
            )
            Text(
                "✕",
                Modifier.align(Alignment.TopEnd).padding(6.dp).clip(CircleShape)
                    .background(Color(0x88000000)).clickable { onDelete(g) }.padding(8.dp, 2.dp),
                color = Color.White
            )
        }
        Text(g.name, Modifier.padding(10.dp, 8.dp, 10.dp, 0.dp), color = Color(0xFFF3ECFF), fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 2)
        Button(onClick = { onPlay(g) }, Modifier.fillMaxWidth().padding(10.dp)) { Text("▶ Играть") }
    }
}

@Composable
fun GameScreen(world: World, count: Int, onExit: () -> Unit) {
    val renderer = remember(world) { GameRenderer(world) }
    val holder = remember { arrayOfNulls<GLSurfaceView>(1) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_PAUSE -> holder[0]?.onPause()
                Lifecycle.Event.ON_RESUME -> holder[0]?.onResume()
                else -> {}
            }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    Box(Modifier.fillMaxSize()) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                GLSurfaceView(ctx).apply {
                    setEGLContextClientVersion(2)
                    setEGLConfigChooser(8, 8, 8, 0, 24, 0)
                    setRenderer(renderer)
                    renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
                    holder[0] = this
                }
            }
        )
        // слой для вращения камеры пальцем
        Box(Modifier.fillMaxSize().pointerInput(renderer) {
            detectDragGestures { change, drag ->
                change.consume()
                renderer.yaw -= drag.x * 0.006f
                renderer.pitch = (renderer.pitch + drag.y * 0.005f).coerceIn(-0.2f, 1.3f)
            }
        })
        Box(Modifier.fillMaxSize().systemBarsPadding().padding(12.dp)) {
            Button(onClick = onExit, modifier = Modifier.align(Alignment.TopStart)) { Text("‹ Выйти") }
            Text(
                "$count объектов\nтяни экран — камера",
                Modifier.align(Alignment.TopEnd), color = Color.White, fontSize = 12.sp, textAlign = TextAlign.End
            )
            Joystick(renderer, Modifier.align(Alignment.BottomStart).padding(12.dp))
            JumpButton(renderer, Modifier.align(Alignment.BottomEnd).padding(20.dp))
        }
    }
}

@Composable
fun Joystick(r: GameRenderer, modifier: Modifier) {
    var knob by remember { mutableStateOf(Offset.Zero) }
    Box(
        modifier.size(130.dp).clip(CircleShape).background(Color(0x554B1DB0))
            .border(2.dp, Color(0x88FFFFFF), CircleShape)
            .pointerInput(Unit) {
                val rad = size.width / 2f
                fun upd(p: Offset) {
                    var dx = (p.x - rad) / rad
                    var dy = (p.y - rad) / rad
                    val l = hypot(dx, dy)
                    if (l > 1f) { dx /= l; dy /= l }
                    r.joyX = dx
                    r.joyY = -dy
                    knob = Offset(dx, dy)
                }
                awaitEachGesture {
                    val down = awaitFirstDown()
                    down.consume()
                    upd(down.position)
                    do {
                        val ev = awaitPointerEvent()
                        val c = ev.changes.firstOrNull { it.id == down.id }
                        if (c != null) { upd(c.position); c.consume() }
                    } while (ev.changes.any { it.id == down.id && it.pressed })
                    r.joyX = 0f
                    r.joyY = 0f
                    knob = Offset.Zero
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier.offset { IntOffset((knob.x * 34.dp.toPx()).toInt(), (knob.y * 34.dp.toPx()).toInt()) }
                .size(56.dp).clip(CircleShape).background(Color(0xDDFFFFFF))
        )
    }
}

@Composable
fun JumpButton(r: GameRenderer, modifier: Modifier) {
    Box(
        modifier.size(84.dp).clip(CircleShape).background(Color(0xCC4B1DB0))
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    down.consume()
                    r.jump = true
                    do {
                        val ev = awaitPointerEvent()
                        ev.changes.forEach { it.consume() }
                    } while (ev.changes.any { it.id == down.id && it.pressed })
                    r.jump = false
                }
            },
        contentAlignment = Alignment.Center
    ) { Text("⇧", color = Color.White, fontSize = 30.sp) }
}

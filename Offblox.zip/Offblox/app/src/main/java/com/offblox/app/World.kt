package com.offblox.app

import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.min

class Box(val x0: Float, val x1: Float, val y0: Float, val y1: Float, val z0: Float, val z1: Float)

/** Вершины: позиция(3) + нормаль(3) + цвет(3) */
class Batch(val v: FloatArray, val idx: ShortArray)

private fun rot(m: FloatArray, a: Float, b: Float, c: Float) = floatArrayOf(
    m[0] * a + m[1] * b + m[2] * c,
    m[3] * a + m[4] * b + m[5] * c,
    m[6] * a + m[7] * b + m[8] * c
)

/** Добавляет коробку №k в массивы (24 вершины и 36 индексов на коробку). */
fun addBox(m: FloatArray, sx: Float, sy: Float, sz: Float, cr: Float, cg: Float, cb: Float,
           v: FloatArray, k: Int, ix: ShortArray) {
    val h = floatArrayOf(sx / 2, sy / 2, sz / 2)
    var vo = k * 216
    var io = k * 36
    val base = k * 24
    var face = 0
    for (a in 0..2) for (sg in intArrayOf(-1, 1)) {
        val b = (a + 1) % 3
        val c = (a + 2) % 3
        val ln = FloatArray(3)
        ln[a] = sg.toFloat()
        val wn = rot(m, ln[0], ln[1], ln[2])
        for (q in 0..3) {
            val lp = FloatArray(3)
            lp[a] = sg * h[a]
            lp[b] = (if (q == 0 || q == 3) 1f else -1f) * h[b]
            lp[c] = (if (q < 2) 1f else -1f) * h[c]
            val w = rot(m, lp[0], lp[1], lp[2])
            v[vo++] = w[0] + m[9]; v[vo++] = w[1] + m[10]; v[vo++] = w[2] + m[11]
            v[vo++] = wn[0]; v[vo++] = wn[1]; v[vo++] = wn[2]
            v[vo++] = cr; v[vo++] = cg; v[vo++] = cb
        }
        val b0 = base + face * 4
        face++
        ix[io++] = b0.toShort(); ix[io++] = (b0 + 1).toShort(); ix[io++] = (b0 + 2).toShort()
        ix[io++] = b0.toShort(); ix[io++] = (b0 + 2).toShort(); ix[io++] = (b0 + 3).toShort()
    }
}

class World(place: Place) {
    val batches = ArrayList<Batch>()
    val avatar: Batch
    val spawn = floatArrayOf(0f, 40f, 0f)
    var minY = 1e9f

    private val grid = HashMap<Long, ArrayList<Box>>()
    private val big = ArrayList<Box>()
    private val tmp = ArrayList<Box>()
    private val off = floatArrayOf(-.7f, .7f)

    private fun key(i: Int, j: Int) = (i.toLong() shl 32) xor (j.toLong() and 0xffffffffL)

    init {
        var best: Box? = null
        var sp: FloatArray? = null
        for (p in place.parts) {
            val m = p.m
            val s = p.s
            if (p.cc) {
                val hx = .5f * (abs(m[0]) * s[0] + abs(m[1]) * s[1] + abs(m[2]) * s[2])
                val hy = .5f * (abs(m[3]) * s[0] + abs(m[4]) * s[1] + abs(m[5]) * s[2])
                val hz = .5f * (abs(m[6]) * s[0] + abs(m[7]) * s[1] + abs(m[8]) * s[2])
                val b = Box(m[9] - hx, m[9] + hx, m[10] - hy, m[10] + hy, m[11] - hz, m[11] + hz)
                minY = min(minY, b.y0)
                val cur = best
                if (cur == null || (b.x1 - b.x0) * (b.z1 - b.z0) > (cur.x1 - cur.x0) * (cur.z1 - cur.z0)) best = b
                val i0 = floor(b.x0 / 32f).toInt(); val i1 = floor(b.x1 / 32f).toInt()
                val j0 = floor(b.z0 / 32f).toInt(); val j1 = floor(b.z1 / 32f).toInt()
                if ((i1 - i0 + 1).toLong() * (j1 - j0 + 1) > 300) big.add(b)
                else for (i in i0..i1) for (j in j0..j1) grid.getOrPut(key(i, j)) { ArrayList() }.add(b)
            }
            if (p.spawn && sp == null) sp = floatArrayOf(m[9], m[10] + s[1] / 2, m[11])
        }
        if (minY > 1e8f) minY = -500f
        val s0 = sp
        val b0 = best
        if (s0 != null) { spawn[0] = s0[0]; spawn[1] = s0[1]; spawn[2] = s0[2] }
        else if (b0 != null) { spawn[0] = (b0.x0 + b0.x1) / 2; spawn[1] = b0.y1; spawn[2] = (b0.z0 + b0.z1) / 2 }

        val vis = place.parts.filter { it.t < 0.9f }
        var i = 0
        while (i < vis.size) {
            val n = min(2700, vis.size - i)
            val v = FloatArray(n * 216)
            val ix = ShortArray(n * 36)
            for (k in 0 until n) {
                val p = vis[i + k]
                addBox(p.m, p.s[0], p.s[1], p.s[2], p.r, p.g, p.b, v, k, ix)
            }
            batches.add(Batch(v, ix))
            i += n
        }

        // человечек: x,y,z центра, размеры, цвет
        val body = arrayOf(
            floatArrayOf(0f, 3f, 0f, 2f, 2f, 1f, .48f, .25f, .9f),
            floatArrayOf(0f, 4.6f, 0f, 1.2f, 1.2f, 1.2f, .96f, .8f, .19f),
            floatArrayOf(-1.5f, 3f, 0f, 1f, 2f, 1f, .96f, .8f, .19f),
            floatArrayOf(1.5f, 3f, 0f, 1f, 2f, 1f, .96f, .8f, .19f),
            floatArrayOf(-.5f, 1f, 0f, 1f, 2f, 1f, .23f, .16f, .54f),
            floatArrayOf(.5f, 1f, 0f, 1f, 2f, 1f, .23f, .16f, .54f)
        )
        val av = FloatArray(body.size * 216)
        val ai = ShortArray(body.size * 36)
        body.forEachIndexed { k, q ->
            addBox(floatArrayOf(1f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f, q[0], q[1], q[2]),
                q[3], q[4], q[5], q[6], q[7], q[8], av, k, ai)
        }
        avatar = Batch(av, ai)
    }

    private fun near(x: Float, z: Float): ArrayList<Box> {
        tmp.clear()
        tmp.addAll(big)
        for (a in off) for (c in off) {
            val l = grid[key(floor((x + a) / 32f).toInt(), floor((z + c) / 32f).toInt())]
            if (l != null) tmp.addAll(l)
        }
        return tmp
    }

    private fun ov(b: Box, x: Float, z: Float) = x + .7f > b.x0 && x - .7f < b.x1 && z + .7f > b.z0 && z - .7f < b.z1

    /** Высота пола под ногами (самая высокая поверхность не выше ноги+1.6). */
    fun top(x: Float, z: Float, y: Float): Float {
        var t = -1e9f
        for (b in near(x, z)) if (ov(b, x, z) && b.y1 <= y + 1.6f && b.y1 > t) t = b.y1
        return t
    }

    /** Стена на пути? */
    fun blocked(x: Float, z: Float, y: Float): Boolean {
        for (b in near(x, z)) if (ov(b, x, z) && b.y1 > y + 1.6f && b.y0 < y + 4.5f) return true
        return false
    }
}

package com.offblox.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class GameEntry(val id: String, val name: String, val count: Int)

/** Библиотека импортированных игр: файлы .rbxl лежат в памяти приложения. */
class Library(ctx: Context) {
    private val dir = File(ctx.filesDir, "games").apply { mkdirs() }
    private val idx = File(dir, "index.json")

    fun list(): List<GameEntry> {
        if (!idx.exists()) return emptyList()
        return try {
            val a = JSONArray(idx.readText())
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                GameEntry(o.getString("id"), o.getString("name"), o.getInt("count"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun save(l: List<GameEntry>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("count", it.count)) }
        idx.writeText(a.toString())
    }

    fun add(name: String, bytes: ByteArray, count: Int): GameEntry {
        val e = GameEntry("g" + System.currentTimeMillis(), name, count)
        File(dir, e.id + ".rbxl").writeBytes(bytes)
        save(list() + e)
        return e
    }

    fun remove(id: String) {
        File(dir, "$id.rbxl").delete()
        save(list().filter { it.id != id })
    }

    fun read(id: String): ByteArray = File(dir, "$id.rbxl").readBytes()
}
